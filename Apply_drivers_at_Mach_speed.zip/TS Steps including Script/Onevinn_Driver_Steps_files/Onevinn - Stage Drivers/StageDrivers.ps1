﻿<#
    Script name: StageDrivers.ps1
    Version: 0.1
    Author: Johan Schrewelius
    Date: 2020-02-28
    Note: Concept, use at own risk
#>

function WriteLog {
    param(
    [Parameter(Mandatory)]
    [string]$LogText,
    [Parameter(Mandatory=$true)]
    $Component,
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet('Info','Warning','Error','Verbose')]
    [string]$Type,
    [Parameter(Mandatory)]
    [string]$LogFileName,
    [Parameter(Mandatory)]
    [string]$FileName
    )

    switch ($Type)
    {
        "Info"      { $typeint = 1 }
        "Warning"   { $typeint = 2 }
        "Error"     { $typeint = 3 }
        "Verbose"   { $typeint = 4 }
    }

    $time = Get-Date -f "HH:mm:ss.ffffff"
    $date = Get-Date -f "MM-dd-yyyy"
    $ParsedLog = "<![LOG[$($LogText)]LOG]!><time=`"$($time)`" date=`"$($date)`" component=`"$($Component)`" context=`"`" type=`"$($typeint)`" thread=`"$($pid)`" file=`"$($FileName)`">"
    $ParsedLog | Out-File -FilePath "$LogFileName" -Append -Encoding utf8
}

function Start-Proc {
    param([string]$Exe = $(Throw "An executable must be specified"),
          [string]$Arguments,
          [string]$WorkDir = $null,
          [switch]$Hidden,
          [switch]$WaitForExit)

    $startinfo = New-Object System.Diagnostics.ProcessStartInfo
    $startinfo.FileName = $Exe
    $startinfo.Arguments = $Arguments
    $startinfo.WorkingDirectory = "$($WorkDir)"
    if ($Hidden) {
        $startinfo.WindowStyle = 'Hidden'
        $startinfo.CreateNoWindow = $True
    }
    $process = [System.Diagnostics.Process]::Start($startinfo)
    if ($WaitForExit) { $process.WaitForExit() }
    return $process.ExitCode
}

function Set-RunFromDP {
    param([string]$Value)

    $Arch = "x86"

    if($env:PROCESSOR_ARCHITECTURE.Equals("AMD64")) {
        $Arch = "x64"
    }
    
    $Arg = "set _SMSTSRunFromDP $($Value)"

    $result = Start-Proc -Exe "TSVars.exe" -Arguments $Arg -WorkDir "$($PSScriptRoot)\$($Arch)" -Hidden -WaitForExit
}

$tsenv = New-Object -COMObject Microsoft.SMS.TSEnvironment

[string]$OSDDriverPackageID = $tsenv.Value("OSDDriverPackageID")
[string]$DriverExePassword = $tsenv.Value("DriverExePassword")
[string]$TargetDisk = $tsenv.Value("OSDTargetSystemDrive")
[string]$ContentPathOnDisk = "$($TargetDisk)\Drivers"
[bool]$SMSTSRunFromDP = $tsenv.Value("_SMSTSRunFromDP").ToLower().Equals("true")
[bool]$SMSTSInWinPE = $tsenv.Value("_SMSTSInWinPE").ToLower().Equals("true")
[string]$LogPath = $tsenv.Value("_SMSTSLogPath")

$Self = $MyInvocation.MyCommand.Name
$LogFile = "$LogPath\Onevinn." + $Self.Replace(".ps1", ".log")
$OSDisk = $LogFile.SubString(0, 2)

WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Script started" -Type Info

if (!$DriverExePassword) {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Self-extractor password missing" -Type Error
    exit 1
}

$tsenv.Value("DriverExePassword") = ""

if ($env:PROCESSOR_ARCHITECTURE.Equals("AMD64")) {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Detected 64-bit environment" -Type Info
    $DownLoadExe = "X:\sms\bin\x64\OSDDownloadContent.exe"
}
else {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Detected 32-bit environment" -Type Info
    $DownLoadExe = "X:\sms\bin\i386\OSDDownloadContent.exe"
}

WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Setting TS variables for dynamic download" -Type Info

$tsenv.Value("OSDDownLoadDownloadPackages") = "$OSDDriverPackageID"
$tsenv.Value("OSDDownloadDestinationLocationType") = "Custom"
$tsenv.Value("OSDDownloadDestinationPath") = "$ContentPathOnDisk"
$tsenv.Value("OSDDownloadDestinationVariable") = "DriverContentPath"
$tsenv.Value("OSDDownloadContinueDownloadOnError") = "True"

try {

    if ($SMSTSRunFromDP) {
        WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Flipping '_SMSTSRunFromDP' to enable download" -Type Info
        Set-RunFromDP -Value "false"
    }

    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Starting download of Package $($OSDDriverPackageID)" -Type Info
    $result = Start-Proc -Exe "$DownLoadExe" -Hidden -WaitForExit

    if ($SMSTSRunFromDP) {
        WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Restoring '_SMSTSRunFromDP' after download" -Type Info
        Set-RunFromDP -Value "false"
    }
}
catch {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Failed to download, Exception: $($_.Exception.Message)" -Type Error
}

WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Resetting variables" -Type Info

$tsenv.Value("OSDDownLoadDownloadPackages") = ""
$tsenv.Value("OSDDownloadDestinationLocationType") = ""
$tsenv.Value("OSDDownloadDestinationPath") = ""
$tsenv.Value("OSDDownloadDestinationVariable") = ""
$tsenv.Value("OSDDownloadContinueDownloadOnError") = ""

$ContentLocation = $tsenv.Value("DriverContentPath01")

if (!$ContentLocation) {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "ContentLocation = null, exiting" -Type Info
    exit 0
}

WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "ContentLocation = $($ContentLocation)" -Type Info

$DriverExe = "$($ContentLocation)\Drivers.exe"

if (!(Test-Path -Path "$DriverExe")) {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "DriverExe does not exist, exiting" -Type Info
    exit 0
}

WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "DriverExe = $($DriverExe)" -Type Info

try {
    $result = Start-Proc -Exe "$DriverExe" -Arguments "-o`"$($ContentPathOnDisk)`" -y -p`"$($DriverExePassword)`"" -Hidden -WaitForExit
    Remove-Item -Path "$($ContentLocation)" -Recurse -Force -EA SilentlyContinue
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Expanded 'Drivers.exe' to '$($ContentPathOnDisk)'" -Type Info
}
catch {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Failed to expand 'Drivers.exe', Exception: $($_.Exception.Message)" -Type Error
    exit 1
}

if (!(Test-Path -Path "$($ContentPathOnDisk)\*")) {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "$($ContentPathOnDisk) is empty" -Type Error
    exit 1
}

try {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Running Dism.exe /Image:$($TargetDisk)\ /Add-Driver /Driver:$($ContentPathOnDisk) /Recurse" -Type Info
    $result = Start-Proc -Exe "Dism.exe" -Arguments "/Image:$($TargetDisk)\ /Add-Driver /Driver:$($ContentPathOnDisk) /Recurse" -Hidden -WaitForExit
}
catch {
    WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Failed to run dism /recurse, Exception: $($_.Exception.Message)" -Type Error
    exit 1
}

Start-Sleep -Milliseconds 2000
WriteLog -LogFileName "$LogFile" -Component "RunPowerShellScript" -FileName "$Self" -LogText "Script finished successfully" -Type Info
